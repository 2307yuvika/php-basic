<?php
$servername="localhost";
$username="root";
$password="Udhaya23";
$dbname="first_db";
$id=$_POST['id'];
// create connection
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
die("connection failed:".$conn->connect_error);
}
$sql="delete from crud where id=".$id;
echo $sql."<br>";
if($conn->query($sql)==TRUE)
{
echo"delete success";
}
else
{
echo $conn->error;
}
$conn->close();
?>