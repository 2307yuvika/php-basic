<?php 
$servername = "localhost";
$username = "root";
$password = "Udhaya23";
$dbname = "first_db";

$name=$_POST['name'];
$email=$_POST['email'];
$gendar=$_POST['gendar'];
$number=$_POST['number'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO crud ( name, email, gendar,number)
VALUES ('$name','$email' ,'$gendar','$number')";
echo $sql;
if ($conn->query($sql) === TRUE) {
  echo "insertion successfully";
} else {
  echo "failed";
}

$conn->close();
?>