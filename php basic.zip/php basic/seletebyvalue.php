<?php
$servername="localhost";
$username="root";
$password="Udhaya23";
$dbname="first_db";
$conn=new mysqli($servername,$username,$password,$dbname);
$name=$_POST['name'];
if($conn->connect_error)
{
die("connection failed".$conn->connect_error);
}
$sql="select * from crud where name='$name'";
//echo $sql;
$res=$conn->query($sql);
if($res->num_rows>0)
{
echo"<table border=1>";
while($row=$res->fetch_assoc())
{
echo"<tr><td>".$row['name']."</td><td>".$row['email']."</td><td>".$row['gendar']."</td><td>".$row['number']."</td></tr>";
}
echo "</table>";
}
else
{
echo"no records";
}
$conn->close();
?>
