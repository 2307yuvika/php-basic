<?php   
$hostname="localhost";
$username="root";
$password="Udhaya23";
$databasename="first_db";
// create connection

//check connection
$connection =  mysqli_connect($hostname, $username, $password,$databasename);
if (!$connection) {
    die("Unable to Connect database: " . mysqli_connect_error());
}

?>