<?php

include('database.php');
class fd{
  // fetch query
 function fetch_data($connection){
  $query="SELECT * from user_details ORDER BY id DESC";
  $exec=mysqli_query($connection, $query);
  if(mysqli_num_rows($exec)>0){

    $row= mysqli_fetch_all($exec, MYSQLI_ASSOC);
    return $row;  
        
  }else{
    return $row=[];
  }
}
}
$fetch_data =new fd();
$fetchData=$fetch_data->fetch_data($connection);
?>

