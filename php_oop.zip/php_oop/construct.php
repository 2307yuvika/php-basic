<?php
//construct

class Fruit {
  public $name;
  public $color;
  
  function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color;
  }
  function get_name() {
    return $this->name;
  }
  function get_color() {
    return $this->color;
  }
}


$apple = new Fruit("Apple", "red");
echo $apple->get_name();
echo "<br>";
echo $apple->get_color();
echo"<br>";


//destruct

 class person{
    public $name;
    public $age;
    function __construct($name,$age){
      $this->name=$name;
      $this->age=$age;
    }
    function get(){
      echo "NAME=".$this->name."AGE=".$this->age."<br>";
    }
    function __destruct(){
      echo"<br>{$this->name}{$this->age}is destroyed";
    }
  }

  
$obj1=new person("preethi",21);
$obj1->get();
$obj2=new person("abi",21);
$obj2->get();
$obj3=new person("udhaya",20);
$obj3->get();
echo"<br>";

//constants

  class car{
    const a="person a";
    function display(){
      echo self::a;
    }
  }

 $obj=new car();
 $obj->display();
 echo"<br>";

//abstract class

abstract class name{
  abstract function display($s);
}
class childB extends name{
  function display($s){
    echo"$s<br>";
  }
}
class childC extends name{
  function display($s){
    echo"$s<br>";
  }
}

$obj4=new childB();
$obj4->display("child B");
$obj5=new childC();
$obj5->display("child C");







?>


  
